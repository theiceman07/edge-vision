__version__ = '0.29.1+cpu'
git_version = '1f1a920d685d46dfbe187934b785b7ecb7a182f2'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
